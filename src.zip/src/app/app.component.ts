import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'listAppTest';

 
  Lists=[{course:"C"}];

  addApp(todo)
  {

    var todos={course:todo};
    this.Lists.push(todos);
    console.log(this.Lists);

  }
  removeApp(courses)
 {
   this.Lists.splice(this.Lists.indexOf(courses),1);
   console.log(this.Lists);
   //this.Lists=this.Lists.filter(l=>l.course!==courses.course);
 }
}
